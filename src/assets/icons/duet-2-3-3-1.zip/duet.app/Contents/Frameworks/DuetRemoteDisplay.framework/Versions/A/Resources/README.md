# DuetCommon
Common packet formats and such
